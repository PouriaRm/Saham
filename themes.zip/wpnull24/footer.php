<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * The template for displaying pages footers
 *
 * Do not overload this file directly. Instead have a look at framework/templates/footer.php: you should find all
 * the needed hooks there.
 */

us_load_template( 'templates/footer' );
